import React from 'react';

import DriverList from './components/DriverList';


function App() {
  return (
    <div className="App">
      <h1>Driver Management System</h1>
      <DriverList />
    </div>
  );
}

export default App;
