// src/components/DriverList.js
import React, { useEffect, useState } from 'react';
import axios from 'axios';

const DriverList = () => {
  const [drivers, setDrivers] = useState([]);

  useEffect(() => {
    axios.get('http://localhost:3001/drivers')
      .then(response => {
        setDrivers(response.data);
      })
      .catch(error => {
        console.error('Error fetching drivers:', error);
      });
  }, []);

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">Drivers List</h2>
      <table className="table-auto w-full border-collapse border border-gray-300">
        <thead>
          <tr className="bg-gray-200">
            <th className="border border-gray-300 px-4 py-2">ID</th>
            <th className="border border-gray-300 px-4 py-2">Name</th>
            <th className="border border-gray-300 px-4 py-2">License</th>
            <th className="border border-gray-300 px-4 py-2">Phone</th>
            <th className="border border-gray-300 px-4 py-2">Status</th>
            <th className="border border-gray-300 px-4 py-2">Experience</th>
            <th className="border border-gray-300 px-4 py-2">Joining Date</th>
            <th className="border border-gray-300 px-4 py-2">Vehicle</th>
          </tr>
        </thead>
        <tbody>
          {drivers.map(driver => (
            <tr key={driver.id}>
              <td className="border border-gray-300 px-4 py-2">{driver.id}</td>
              <td className="border border-gray-300 px-4 py-2">{driver.name}</td>
              <td className="border border-gray-300 px-4 py-2">{driver.licenseNumber}</td>
              <td className="border border-gray-300 px-4 py-2">{driver.phone}</td>
              <td className="border border-gray-300 px-4 py-2">{driver.status}</td>
              <td className="border border-gray-300 px-4 py-2">{driver.experience}</td>
              <td className="border border-gray-300 px-4 py-2">{driver.joiningDate}</td>
              <td className="border border-gray-300 px-4 py-2">{driver.vehicleAssigned}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default DriverList;
