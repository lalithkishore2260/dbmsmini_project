const express = require('express');
const mysql = require('mysql2');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
const port = 3001;

app.use(cors());
app.use(bodyParser.json());

// MySQL connection
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: 'dbms', // Replace with your MySQL password
  database: 'jbs_travels' // Replace with your actual database name
});

db.connect(err => {
  if (err) {
    console.error('Database connection failed: ' + err.stack);
    return;
  }
  console.log('Connected to MySQL database.');
});

// Get all drivers
app.get('/drivers', (req, res) => {
    const sql = 'SELECT * FROM drivers';
    db.query(sql, (err, results) => {
      if (err) {
        console.error('Error fetching data:', err);
        res.status(500).send('Error retrieving drivers');
      } else {
        res.json(results);
      }
    });
  });

// Add a new driver
app.post('/drivers', (req, res) => {
  const { name, licenseNumber, phone, status, experience, joiningDate, vehicleAssigned } = req.body;
  const sql = 'INSERT INTO drivers (name, licenseNumber, phone, status, experience, joiningDate, vehicleAssigned) VALUES (?, ?, ?, ?, ?, ?, ?)';
  db.query(sql, [name, licenseNumber, phone, status, experience, joiningDate, vehicleAssigned], (err, result) => {
    if (err) return res.status(500).send(err);
    res.json({ message: 'Driver added successfully', id: result.insertId });
  });
});

// Update a driver
app.put('/drivers/:id', (req, res) => {
  const { id } = req.params;
  const { name, licenseNumber, phone, status, experience, joiningDate, vehicleAssigned } = req.body;
  const sql = 'UPDATE drivers SET name=?, licenseNumber=?, phone=?, status=?, experience=?, joiningDate=?, vehicleAssigned=? WHERE id=?';
  db.query(sql, [name, licenseNumber, phone, status, experience, joiningDate, vehicleAssigned, id], (err) => {
    if (err) return res.status(500).send(err);
    res.json({ message: 'Driver updated successfully' });
  });
});

// Delete a driver
app.delete('/drivers/:id', (req, res) => {
  const { id } = req.params;
  db.query('DELETE FROM drivers WHERE id=?', [id], (err) => {
    if (err) return res.status(500).send(err);
    res.json({ message: 'Driver deleted successfully' });
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running at http://localhost:${port}`);
});
